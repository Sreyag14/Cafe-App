package com.example.ru_cafe_app;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Locale;

public class CoffeeActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final DecimalFormat df = new DecimalFormat("0.00");
    private TextView sweetCreamBox, irishCreamBox, frenchVanillaBox, caramelBox, mochaBox;
    private String size ="short";
    private TextView totalAmount;

    private int sweetCreamQuantity = 0;
    private int irishCreamQuantity = 0;
    private int frenchVanillaQuantity = 0;
    private int caramelQuantity = 0;
    private int mochaQuantity = 0;
    private int coffeeQuantity = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coffee);

        // Initialize views
        sweetCreamBox = findViewById(R.id.sweetCream);
        irishCreamBox = findViewById(R.id.irishCream);
        frenchVanillaBox = findViewById(R.id.frenchVanilla);
        caramelBox = findViewById(R.id.caramel);
        mochaBox = findViewById(R.id.mocha);
        totalAmount = findViewById(R.id.coffeeTotalOrder2);


        // Set up spinner for coffee quantity
        Spinner spinner = findViewById(R.id.coffeeSize);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.coffeesize, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        Spinner spinner2 = findViewById(R.id.coffeeQuantity);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(
                this, R.array.coffee_quantity_array, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(this);

        // Set onClick listeners for flavor buttons
        findViewById(R.id.incrementSweetCream).setOnClickListener(v -> incrementQuantity("sweet cream"));
        findViewById(R.id.decrementSweetCream).setOnClickListener(v -> decrementQuantity("sweet cream"));
        findViewById(R.id.incrementFrenchVanilla).setOnClickListener(v -> incrementQuantity("french vanilla"));
        findViewById(R.id.decrementFrenchVanilla).setOnClickListener(v -> decrementQuantity("french vanilla"));
        findViewById(R.id.incrementCaramel).setOnClickListener(v -> incrementQuantity("caramel"));
        findViewById(R.id.decrementCaramel).setOnClickListener(v -> decrementQuantity("caramel"));
        findViewById(R.id.incrementMocha).setOnClickListener(v -> incrementQuantity("mocha"));
        findViewById(R.id.decrementMocha).setOnClickListener(v -> decrementQuantity("mocha"));
        findViewById(R.id.incrementIrishCream).setOnClickListener(v -> incrementQuantity("irish cream"));
        findViewById(R.id.decrementIrishCream).setOnClickListener(v -> decrementQuantity("irish cream"));


        // Update total amount on initial load
        updateTotalAmount();
    }
    private void updateTotalAmount() {
        // Check if size and coffeeQuantity are not null
        if (size != null && coffeeQuantity > 0) {
            totalAmount.setText(df.format(calculateTotalPrice()));
        }
    }
    private void incrementQuantity(String flavor) {
        switch (flavor) {
            case "sweet cream":
                sweetCreamQuantity++;
                break;
            case "irish cream":
                irishCreamQuantity++;
                break;
            case "french vanilla":
                frenchVanillaQuantity++;
                break;
            case "caramel":
                caramelQuantity++;
                break;
            case "mocha":
                mochaQuantity++;
                break;
        }
        updateTotalAmount(); // Update total price
    }

    // Implement flavor quantity decrement
    private void decrementQuantity(String flavor) {
        switch (flavor) {
            case "sweet cream":
                if (sweetCreamQuantity > 0) sweetCreamQuantity--;
                break;
            case "irish cream":
                if (irishCreamQuantity > 0) irishCreamQuantity--;
                break;
            case "french vanilla":
                if (frenchVanillaQuantity > 0) frenchVanillaQuantity--;
                break;
            case "caramel":
                if (caramelQuantity > 0) caramelQuantity--;
                break;
            case "mocha":
                if (mochaQuantity > 0) mochaQuantity--;
                break;
        }
        updateTotalAmount(); // Update total price
    }

    // Other methods remain unchanged

    // Update calculateTotalPrice to consider flavor quantities
    private double calculateTotalPrice() {
        double total = 0.0;

        // Calculate base price based on selected size
        CupSize cupSize = CupSize.valueOf(size.toUpperCase());

       // Coffee coffee = new Coffee(cupSize,);

        total += cupSize.getPrice()*coffeeQuantity; // Add base price

        // Add additional prices for selected flavors and quantities
        total += sweetCreamQuantity * 0.30;
        total += irishCreamQuantity * 0.30;
        total += frenchVanillaQuantity * 0.30;
        total += caramelQuantity * 0.30;
        total += mochaQuantity * 0.30;

        return total;
    }
    /**
     * when the items are selected it calculates the total amount
     * @param parent The AdapterView where the selection happened
     * @param view The view within the AdapterView that was clicked
     * @param position The position of the view in the adapter
     * @param id The row id of the item that is selected
     */
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String choice = parent.getItemAtPosition(position).toString();

        // Update the size only if the selection is from the coffee size spinner
        if (parent.getId() == R.id.coffeeSize) {
            size = choice;
        }

        // Update coffeeQuantity when the coffee quantity spinner item is selected
        if (parent.getId() == R.id.coffeeQuantity) {
            coffeeQuantity = Integer.parseInt(choice);
        }

        // Update total amount based on the new quantity
        updateTotalAmount();
    }


    /**
     * adds the base price
     * @param parent The AdapterView that now contains no selected item.
     */
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        totalAmount.setText(df.format(calculateTotalPrice()));
    }
    /**
     * displays the total price
     * @param view
     */
    public void displayAmount(View view){
        totalAmount.setText((df.format(calculateTotalPrice())));
    }
    public void addToOrder(View view){
        totalAmount.setText(String.valueOf(df.format(calculateTotalPrice())));
        CupSize cupSize = CupSize.valueOf(size);
        ArrayList<String> addIns = new ArrayList<>();
        if(frenchVanillaQuantity > 0){
            addIns.add("frenchVanilla");
        }
        if(sweetCreamQuantity > 0){
            addIns.add("sweet cream");
        }
        if(irishCreamQuantity > 0){
            addIns.add("irish cream");
        }
        if(caramelQuantity > 0){
            addIns.add("caramel");
        }
        if(mochaQuantity > 0){
            addIns.add("mocha");
        }
        Coffee c = new Coffee(cupSize, addIns, coffeeQuantity);
        MainActivity.items.add("Coffee (1) " + c.toString());
        double b = Double.parseDouble(df.format(calculateTotalPrice()));
        MainActivity.list_cost.add(b);
        Toast.makeText(this, "added to order", Toast.LENGTH_SHORT).show();
    }
}
