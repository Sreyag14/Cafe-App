package com.example.ru_cafe_app;

public class Item {

    String name;
    String cost;

    int image;

    /**
     * constructor
     * @param name
     * @param cost
     * @param image
     */
    public Item(String name, String cost, int image) {
        this.name = name;
        this.cost = cost;
        this.image = image;
    }

    /**
     * name getter
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * cost getter
     * @return
     */
    public String getCost() {
        return cost;
    }

    /**
     * name setter
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * cost setter
     * @param cost
     */
    public void setCost(String cost) {
        this.cost = cost;
    }

    /**
     * image setter
     * @param image
     */
    public void setImage(int image) {
        this.image = image;
    }

    /**
     * image getter
     * @return
     */
    public int getImage() {
        return image;
    }

}