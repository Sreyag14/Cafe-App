package com.example.ru_cafe_app;

/**
 * Enum class for added coffee flavors
 * @author Arnitha Nayana, Sreya Gopalam
 */
public enum Syrup {
    SWEET("sweet cream"),
    FRENCH("french vanilla"),
    IRISH("irish cream"),
    CARAMEL("caramel"),
    MOCHA("mocha");

    private final String syrup;
    Syrup(String syrup)
    {
        this.syrup=syrup;
    }

    /**
     * Return syrup name
     * @return syrup
     */
    public String getSyrup() {
        return syrup;
    }
}
