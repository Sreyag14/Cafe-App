package com.example.ru_cafe_app;

/**
 * Enum class for sandwich add-ons
 */
public enum Toppings {
    LETTUCE("lettuce", 0.30),
    TOMATOES("tomatoes", 0.30),
    ONIONS("onions", 0.30),
    CHEESE("cheese", 1.00);

    private final String topping;
    private final double price;

    Toppings(String topping, double price) {
        this.topping = topping;
        this.price = price;
    }

    /**
     * Returns the topping name
     * @return topping name
     */
    public String getTopping() {
        return topping;
    }

    /**
     * Returns the price of the topping
     * @return topping price
     */
    public double getPrice() {
        return price;
    }
}
