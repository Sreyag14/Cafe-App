package com.example.ru_cafe_app;

/**
 * Enum class for donut types
 * @author Arnitha Nayana, Sreya Gopalam
 */
public enum DonutType {
    YEAST(1.79,"yeast"),
    CAKE(1.89,"cake"),
    HOLES(0.39,"holes");

    private final String donut;
    private final double price;

    /**
     * Sets donut type
     * @param donut
     */
    DonutType(double price, String donut)
    {
        this.donut=donut;
        this.price=price;
    }

    /**
     * Returns price of the specific donut
     * @return price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Returns donut type
     * @return donut
     */
    public String getDonut()
    {
        return donut;
    }
}
