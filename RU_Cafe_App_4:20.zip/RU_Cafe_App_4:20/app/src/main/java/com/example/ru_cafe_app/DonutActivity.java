package com.example.ru_cafe_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class DonutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donut);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        List<Item> items = new ArrayList<>();

        addDonutOption(items, DonutType.YEAST, DonutFlavors.LEMON, 1, R.drawable.lemon_donut);
        addDonutOption(items, DonutType.YEAST, DonutFlavors.MANGO, 1, R.drawable.mango_donut);
        addDonutOption(items, DonutType.YEAST, DonutFlavors.MAPLE, 1, R.drawable.maple_donut);
        addDonutOption(items, DonutType.YEAST, DonutFlavors.MATCHA, 1, R.drawable.matcha_donut);
        addDonutOption(items, DonutType.YEAST, DonutFlavors.COFFEE, 1, R.drawable.coffee_donut);
        addDonutOption(items, DonutType.YEAST, DonutFlavors.GLAZED, 1, R.drawable.glazed_donut);
        addDonutOption(items, DonutType.CAKE, DonutFlavors.BLUEBERRY, 1, R.drawable.blue_cake);
        addDonutOption(items, DonutType.CAKE, DonutFlavors.BIRTHDAY, 1, R.drawable.birthday_cake);
        addDonutOption(items, DonutType.CAKE, DonutFlavors.ORANGE, 1, R.drawable.orange_cake);
        addDonutOption(items, DonutType.CAKE, DonutFlavors.VANILLA, 1, R.drawable.vanilla_holes);
        addDonutOption(items, DonutType.HOLES, DonutFlavors.CHOCOLATE, 1, R.drawable.choc_holes);
        addDonutOption(items, DonutType.HOLES, DonutFlavors.STRAWBERRY, 1, R.drawable.straw_holes);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Adapter(getApplicationContext(), items));
    }

    // Helper method to add a donut option to the items list
    private void addDonutOption(List<Item> items, DonutType type, DonutFlavors flavor, int quantity, int image) {
        Donut donut = new Donut(type, flavor, quantity);
        items.add(new Item(donut.getName(), "$" + String.format("%.2f", donut.price()), image));
    }
}
