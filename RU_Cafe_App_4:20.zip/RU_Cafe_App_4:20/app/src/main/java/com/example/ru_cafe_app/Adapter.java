package com.example.ru_cafe_app;


import android.content.Context;import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<ViewHolder>{
    Context context;

    List<Item> items;

    /**
     * constructor
     * @param context
     * @param items
     */
    public Adapter(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
    }

    /**
     * onCreateViiewHolder() method
     * @param parent The ViewGroup into which the new View will be added after it is bound to
     *               an adapter position.
     * @param viewType The view type of the new View.
     *
     * @return
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.itemview,parent,false));
    }

    /**
     * onBindViewHolder() method
     * @param holder The ViewHolder which should be updated to represent the contents of the
     *        item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.donutNameView.setText(items.get(position).getName());
        holder.cost.setText(items.get(position).getCost());
        holder.imageView.setImageResource(items.get(position).getImage());
    }

    /**
     * count of items
     * @return
     */
    @Override
    public int getItemCount() {
        return items.size();
    }


}
