package com.example.ru_cafe_app;

import java.util.ArrayList;

public class Coffee extends MenuItem {
    private CupSize cupSize;
    private ArrayList<String> syrups;
    private int quantity;

    public Coffee(CupSize cupSize, ArrayList<String> syrups, int quantity) {
        super("Coffee",quantity);
        this.cupSize = cupSize;
        this.syrups = syrups;
        this.quantity = quantity;
    }

    public CupSize getCupSize() {
        return cupSize;
    }

    public ArrayList<String> getSyrups() {
        return syrups;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public double price() {
        double basePrice = cupSize.getPrice();
        double syrupPrice = syrups.size() * 0.30;
        return (basePrice + syrupPrice) * quantity;
    }

    @Override
    public String toString(){
        return "Coffee: " + cupSize + " with syrups " + syrups + " - Quantity: " + quantity;
    }


}



