package com.example.ru_cafe_app;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.ObservableArrayList;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class CurrentActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    private static final double SALES_TAX = 6.625;
    private static TextView subTotal;
    private static TextView tax;
    private static TextView totalAmount;
    private static ListView listOrder;
    private static ArrayList<String> runningTotal = new ArrayList<>();

    /**
     * method to return
     * @return
     */
    public static ArrayList getRunningTotal(){
        return runningTotal;
    }

    private static ObservableArrayList<String> list = new ObservableArrayList<>();
    private static ArrayAdapter<String> l1;
    private static final DecimalFormat df = new DecimalFormat("0.00");


    /**
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.currentorder);
        subTotal = (TextView) findViewById(R.id.subnum);
        tax = (TextView) findViewById(R.id.salenum);
        totalAmount = (TextView) findViewById(R.id.totalnum);
        listOrder = (ListView) findViewById(R.id.orderlist);
        showName(MainActivity.items, MainActivity.list_cost);
    }

    /**
     * calculates the amount of everything
     */
    private void calculateAmount(){
        double total = 0;
        for(double num : MainActivity.list_cost){
            total = total + num;}
        subTotal.setText(df.format(total));
        double amt = (total*SALES_TAX)/100;
        tax.setText(df.format(amt));
        double totalAmt = amt + total;
        totalAmount.setText(df.format(totalAmt));
        runningTotal.add(df.format(total));
        runningTotal.add(df.format(amt));
        runningTotal.add(df.format(totalAmt));
    }

    /***
     * displays the name
     * @param ace
     * @param cost
     */
    public void showName(ArrayList<String> ace, ArrayList<Double> cost){
        calculateAmount();
        for(String name : ace){
            list.add(name);}
        listOrder.setOnItemClickListener(this);
        l1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listOrder.setAdapter(l1);


    }


    /**
     * toast for different clicks
     * @param adapterView The AdapterView where the click happened.
     * @param view The view within the AdapterView that was clicked (this
     *            will be a view provided by the adapter)
     * @param i The position of the view in the adapter.
     * @param l The row id of the item that was clicked.
     */
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("remove?");
        builder.setMessage("are you sure?");
        int index = i;
        builder.setPositiveButton("remove item", new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                list.remove(index);
                MainActivity.items.remove(index);
                l1.notifyDataSetChanged();
                MainActivity.list_cost.remove(index);
                calculateAmount();
                Toast.makeText(CurrentActivity.this, "item removed", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("go back", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int i){
                Toast.makeText(CurrentActivity.this, " your cart", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /**
     * confirms the order and adds it to the store order
     * @param view
     */

    /*
    public void finalizeOrder(View view){
        if(listOrder.getCount()!=0){
            Toast.makeText(this, "added to store order!", Toast.LENGTH_SHORT).show();
            int a = StoreOrderActivity.getInt();
            int b = a + 1;
            StoreOrderActivity.setInt(b);
            subTotal.setText("0.00");
            tax.setText("0.00");
            totalAmount.setText("0.00");
           MainActivity.duplicateOrder();
            MainActivity.list_cost.clear();
            MainActivity.items.clear();
            list.clear();
            l1.notifyDataSetChanged();

        }
        else{
            Toast.makeText(this, "empty", Toast.LENGTH_SHORT).show();
        }
    }

     */
}

