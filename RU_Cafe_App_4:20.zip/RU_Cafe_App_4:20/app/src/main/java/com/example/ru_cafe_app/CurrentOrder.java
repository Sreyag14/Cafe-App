package com.example.ru_cafe_app;

import java.util.ArrayList;
import java.util.List;

public class CurrentOrder {
    private static final double SALES_TAX_RATE = 0.06625; // New Jersey sales tax rate
    private List<MenuItem> items;

    public CurrentOrder() {
        this.items = new ArrayList<>();
    }

    public void addItem(MenuItem item) {
        items.add(item);
    }

    public void removeItem(MenuItem item) {
        items.remove(item);
    }

    public List<MenuItem> getItems() {
        return items;
    }

    public double calculateSubtotal() {
        double subtotal = 0.0;
        for (MenuItem item : items) {
            subtotal += item.price();
        }
        return subtotal;
    }

    public double calculateSalesTax() {
        return calculateSubtotal() * SALES_TAX_RATE;
    }

    public double calculateTotal() {
        return calculateSubtotal() + calculateSalesTax();
    }

    public void clearOrder() {
        items.clear();
    }
    public String toString(){
        String total = "";
        for(MenuItem m: items){
            total+=items;
        }
        return total;
    }
}



