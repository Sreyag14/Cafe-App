package com.example.ru_cafe_app;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<String> items = new ArrayList<>();
    public static ArrayList<Double> list_cost = new ArrayList<>();
    /**
     * onCreate() method
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most*
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);
    }

    /**
     * switches to donut page
     * @param view
     */
    public void orderDonutPage(View view){
        Intent intent = new Intent(this, DonutActivity.class);
        startActivity(intent);
    }

    /**
     * switches to coffee page
     * @param view
     */
    public void orderCoffeePage(View view){
        Intent intent = new Intent(MainActivity.this, CoffeeActivity.class);
        this.startActivity(intent);
    }

    /**
     * switches to cart page
     * @param view
     */
    public void orderCartPage(View view){
        Intent intent = new Intent(this, CurrentActivity.class);
        startActivity(intent);
    }
}
