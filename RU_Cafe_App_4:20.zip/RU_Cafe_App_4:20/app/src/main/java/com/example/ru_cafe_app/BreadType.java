package com.example.ru_cafe_app;

/**
 * Enum class for bread types used in sandwiches
 */
public enum BreadType {
    BAGEL("bagel"),
    WHEATBREAD("wheatbread"),
    SOURDOUGH("sourdough");

    private final String bread;

    BreadType(String bread) {
        this.bread = bread;
    }

    /**
     * Returns the bread type
     * @return bread type
     */
    public String getBread() {
        return bread;
    }
}

