package com.example.ru_cafe_app;


import java.util.ArrayList;

/**
 * Class representing a donut menu item
 * @author Arnitha Nayana, Sreya Gopalam
 */
public class Donut extends MenuItem {
    private final DonutType type;
    private final DonutFlavors flavor;
    private final int quantity;

    /**
     * Constructor for Donut
     * @param type The type of donut
     * @param flavor The flavor of the donut
     * @param quantity The quantity of the donut
     */
    public Donut(DonutType type, DonutFlavors flavor, int quantity) {
        super("Donut",quantity);
        this.type = type;
        this.flavor = flavor;
        this.quantity = quantity;
    }

    /**
     * Returns the price of the donut
     * @return The price of the donut
     */
    @Override
    public double price() {
        return type.getPrice() * quantity;
    }
    public String getName(){
        return flavor.getFlavor()+ " "+type.getDonut()+" donuts";
    }

    /**
     * Returns the type of the donut
     * @return The type of the donut
     */
    public DonutType getType() {
        return type;
    }

    /**
     * Returns the flavor of the donut
     * @return The flavor of the donut
     */
    public DonutFlavors getFlavor() {
        return flavor;
    }

    /**
     * Returns the quantity of the donut
     * @return The quantity of the donut
     */
    public int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return "Donut: " + type + " with flavors " + flavor + " - Quantity: " + quantity;
    }
}




