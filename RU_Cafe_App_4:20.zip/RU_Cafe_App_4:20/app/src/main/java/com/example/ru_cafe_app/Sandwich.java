package com.example.ru_cafe_app;

import java.util.ArrayList;

public class Sandwich extends MenuItem{
    private Protein protein;
    private BreadType bread;
    private ArrayList<String> toppings;
    private int quantity;

    public Sandwich(Protein protein, BreadType bread,ArrayList<String>toppings, int quantity) {
        super("Sandwich",1);
        this.protein = protein;
        this.bread = bread;
        this.toppings = new ArrayList<>();
        this.quantity = quantity;
    }



    @Override
    public double price() {
        double totalPrice = protein.getPrice();
        for (String topping : toppings) {
            totalPrice += Toppings.valueOf(topping).getPrice();
        }
        return totalPrice;
    }



    @Override
    public String toString() {
        return "Sandwich: " + bread + " with " + protein + " and toppings " + toppings + " - Quantity: " + quantity; }



}
