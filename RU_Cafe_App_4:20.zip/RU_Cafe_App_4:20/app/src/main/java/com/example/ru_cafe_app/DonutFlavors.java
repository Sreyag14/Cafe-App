package com.example.ru_cafe_app;

/**
 * Enum class for donut flavors
 * @author Arnitha Nayana, Sreya Gopalam
 */
public enum DonutFlavors {


    BLUEBERRY("blueberry"),
    BIRTHDAY("birthday"),
    ORANGE("orange"),


    //Donut Holes
    VANILLA("vanilla"),
    CHOCOLATE("chocolate"),
    STRAWBERRY("Strawberry"),

    //yeast

    GLAZED("glazed"),
    LEMON("lemon"),
    MATCHA("matcha"),
    MAPLE("maple"),
    COFFEE("coffee"),
    MANGO ("mango");



    private final String flavor;

    DonutFlavors(String flavor)
    {
        this.flavor=flavor;
    }

    /**
     * returns flavor name
     * @return flavor
     */
    public String getFlavor() {
        return flavor;
    }

    public static DonutFlavors getFlavorByName(String name) {
        for (DonutFlavors flavor : DonutFlavors.values()) {
            if (flavor.getFlavor().equalsIgnoreCase(name.toLowerCase())) {
                return flavor;
            }
        }
        return CHOCOLATE; // Default to chocolate flavor if not recognized
    }
}
