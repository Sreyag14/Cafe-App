package com.example.ru_cafe_app;



import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewHolder extends RecyclerView.ViewHolder {
    ImageView imageView;
    TextView donutNameView, cost;
    private Button addButton;

    public ViewHolder(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageviewR);
        donutNameView = itemView.findViewById(R.id.donutname1);
        cost = itemView.findViewById(R.id.donutcost);
        addButton = itemView.findViewById(R.id.plusbutton);
        setAddButtonOnClick(itemView);
    }

    private void setAddButtonOnClick(@NonNull View itemView) {
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alert = new AlertDialog.Builder(itemView.getContext());
                alert.setTitle("Add to order");
                alert.setMessage("Add " + donutNameView.getText().toString() + " to order?");
                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String donutName = donutNameView.getText().toString();
                        DonutType type = getTypeFromName(donutName);;
                        MainActivity.items.add(donutName);
                        MainActivity.list_cost.add(type.getPrice());
                        Toast.makeText(itemView.getContext(), donutName + " added to cart!", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(itemView.getContext(), "More donuts", Toast.LENGTH_SHORT).show();
                    }
                });
                AlertDialog dialog = alert.create();
                dialog.show();
            }
        });
    }

    private DonutType getTypeFromName(String name) {
        String[] fragments = name.split(" ");
        if (fragments.length > 1) {
            String typeStr = fragments[fragments.length - 2].toLowerCase();
            switch (typeStr) {
                case "yeast":
                    return DonutType.YEAST;
                case "cake":
                    return DonutType.CAKE;
                case "holes":
                    return DonutType.HOLES;
                default:
                    return DonutType.YEAST; // Default to yeast if type is unknown
            }
        }
        return DonutType.YEAST; // Default to yeast if type cannot be determined
    }
}

