package com.example.ru_cafe_app;

public abstract class MenuItem {
    private String name;
    private double quantity;

    public MenuItem(String name, int quantity){
        this.name = name;
        this.quantity = quantity;
    }
    public abstract double price();

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }




}
