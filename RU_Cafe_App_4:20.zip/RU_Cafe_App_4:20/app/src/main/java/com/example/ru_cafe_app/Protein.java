package com.example.ru_cafe_app;

/**
 * Enum class for the protein options in sandwiches
 */
public enum Protein {
    BEEF("beef", 10.99),
    FISH("fish", 9.99),
    CHICKEN("chicken", 8.99);

    private final String protein;
    private final double price;

    Protein(String protein, double price) {
        this.protein = protein;
        this.price = price;
    }

    /**
     * Returns the protein type
     * @return protein type
     */
    public String getProtein() {
        return protein;
    }

    /**
     * Returns the price of the protein
     * @return protein price
     */
    public double getPrice() {
        return price;
    }
}
