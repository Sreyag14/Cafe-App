package com.example.ru_cafe_app;

/**
 * Enum for coffee cup size
 * @author Arnitha Nayana, Sreya Gopalam
 */
public enum CupSize {
    SHORT("short",1.99),
    TALL("tall",2.49),
    GRANDE("grande",2.99),
    VENTI("venti",3.49);

    private final String size;
    private final double price;

    CupSize(String size, double price)
    {
        this.size=size;
        this.price = price;
    }

    /**
     * returns cup size
     * @return size
     */
    public String getSize() {
        return size;
    }

    public double getPrice() {
        return price;
    }
}
